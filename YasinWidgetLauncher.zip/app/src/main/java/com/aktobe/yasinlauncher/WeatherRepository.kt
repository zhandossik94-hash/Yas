package com.aktobe.yasinlauncher

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

data class HourlyForecast(
    val time: String,
    val temp: Int,
    val condition: String
)

data class AktobeWeather(
    val currentTemp: Int,
    val windSpeed: Int,
    val conditionText: String,
    val hourly: List<HourlyForecast>
)

object WeatherRepository {
    // Координаты Актюбинска: 50.2839, 57.1670 (Open-Meteo, без API-ключей)
    private const val API_URL =
        "https://api.open-meteo.com/v1/forecast?latitude=50.2839&longitude=57.1670&current=temperature_2m,weather_code,wind_speed_10m&hourly=temperature_2m,weather_code&timezone=Asia%2FAqtobe&forecast_days=2"

    suspend fun fetchWeather(): AktobeWeather? = withContext(Dispatchers.IO) {
        try {
            val url = URL(API_URL)
            val conn = url.openConnection() as HttpURLConnection
            conn.connectTimeout = 8000
            conn.readTimeout = 8000
            conn.requestMethod = "GET"

            if (conn.responseCode != 200) return@withContext null

            val response = conn.inputStream.bufferedReader().use { it.readText() }
            val json = JSONObject(response)

            val current = json.getJSONObject("current")
            val currentTemp = Math.round(current.getDouble("temperature_2m")).toInt()
            val windSpeed = Math.round(current.getDouble("wind_speed_10m")).toInt()
            val currentCode = current.getInt("weather_code")

            val hourlyObj = json.getJSONObject("hourly")
            val times = hourlyObj.getJSONArray("time")
            val temps = hourlyObj.getJSONArray("temperature_2m")
            val codes = hourlyObj.getJSONArray("weather_code")

            val now = LocalDateTime.now()
            val formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:00")
            val currentHourStr = now.format(formatter)

            var startIndex = 0
            for (i in 0 until times.length()) {
                if (times.getString(i) >= currentHourStr) {
                    startIndex = i
                    break
                }
            }

            val slots = mutableListOf<HourlyForecast>()
            // Берем 6 точек с шагом в 2 часа (на ближайшие 12 часов)
            for (step in 0 until 6) {
                val idx = startIndex + (step * 2)
                if (idx < times.length()) {
                    val rawTime = times.getString(idx) // "2026-11-23T15:00"
                    val shortTime = rawTime.substringAfter("T")
                    val tempVal = Math.round(temps.getDouble(idx)).toInt()
                    val codeVal = codes.getInt(idx)
                    slots.add(
                        HourlyForecast(
                            time = shortTime,
                            temp = tempVal,
                            condition = mapWeatherCode(codeVal)
                        )
                    )
                }
            }

            AktobeWeather(
                currentTemp = currentTemp,
                windSpeed = windSpeed,
                conditionText = mapWeatherCode(currentCode),
                hourly = slots
            )
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    private fun mapWeatherCode(code: Int): String {
        return when (code) {
            0 -> "Ясно"
            1, 2 -> "Малооблачно"
            3 -> "Пасмурно"
            45, 48 -> "Туман"
            51, 53, 55, 61, 63, 65, 80, 81, 82 -> "Дождь"
            56, 57, 66, 67 -> "Ледяной дождь"
            71, 73, 75, 77, 85, 86 -> "Снег"
            95, 96, 99 -> "Гроза"
            else -> "Облачно"
        }
    }
}
